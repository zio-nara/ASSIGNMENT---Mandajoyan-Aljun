<?php
$valid_api_keys = [
    'key123' => 'UserA',
    'key456' => 'UserB'
];
