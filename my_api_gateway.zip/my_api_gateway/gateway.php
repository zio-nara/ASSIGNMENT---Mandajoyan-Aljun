<?php
require_once 'config.php';

function get_api_key() {
    $headers = getallheaders();
    if (isset($headers['X-API-Key'])) {
        return $headers['X-API-Key'];
    } elseif (isset($_SERVER['HTTP_X_API_KEY'])) {
        return $_SERVER['HTTP_X_API_KEY'];
    }
    return null;
}


function send_response($code, $data) {
    http_response_code($code);
    echo json_encode($data);
    log_request($code);
    exit;
}

function log_request($status) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $path = $_GET['request_path'] ?? 'Unknown';
    $api_key = get_api_key() ?? 'None';
    $log = "[" . date("Y-m-d H:i:s") . "] - IP: $ip - API Key: $api_key - Path: $path - Status: $status\n";
    file_put_contents(__DIR__ . "/logs/gateway.log", $log, FILE_APPEND);
}

function check_rate_limit($api_key) {
    $file = __DIR__ . "/ratelimit_data/$api_key.json";
    $now = time();

    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        if ($now - $data['timestamp'] > 60) {
            $data = ['timestamp' => $now, 'count' => 1];
        } else {
            if ($data['count'] >= 10) {
                send_response(429, ["error" => "Rate limit exceeded"]);
            }
            $data['count']++;
        }
    } else {
        $data = ['timestamp' => $now, 'count' => 1];
    }

    file_put_contents($file, json_encode($data));
}

// API Key check
$api_key = get_api_key();
if (!$api_key || !isset($valid_api_keys[$api_key])) {
    send_response(401, ["error" => "Invalid or missing API Key"]);
}

// Rate limiting
check_rate_limit($api_key);

// Routing
$path = $_GET['request_path'] ?? '';
switch ($path) {
    case 'users':
        require 'services/service_users.php';
        break;
    case 'products':
        require 'services/service_products.php';
        break;
    default:
        send_response(404, ["error" => "Not Found"]);
}
